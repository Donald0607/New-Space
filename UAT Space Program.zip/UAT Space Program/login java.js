function login()
{
    //alert("try");
    var username = document.getElementById("username").value;
    var accesscode = document.getElementById("security code").value;
    //alert(username)
   
    if ( accesscode > 1000 || username.length > 20)
    {
        document.getElementById("login status").innerHTML = "Login Rejected try again"
        alert(credentials)
    }
    else{
        location.replace("file:///C:/Users/18157/javascript%203/music%20player/Music%20Player.html")
    }
}   