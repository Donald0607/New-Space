function Countdown()
{
    var currTime = 10;

    var i = 10;

    while (i>=0) {

        if (currTime == 5)
        {
            setTimeout(function () {

                document.getElementById("counter").innerHTML = "Warning Less than ½ way to launch, time left = " + currTime;
    
                currTime = currTime - 1;
    
            }, 1000 * i);
    
            i -= 1;
        }
        if (currTime == 0)
        {
            document.getElementById("counter").innerHTML = "Blast OFF"; 
        }
        else
        {
        setTimeout(function () {

            document.getElementById("counter").innerHTML = "the time left is " + currTime;

            currTime = currTime - 1;

        }, 1000 * i);

        i -= 1; /* same as i = i-1 */
        }
    };

 
}
    /* if (i == 5)
    {
        alert("halfway there")
    } 


   while(i>0)
   {
    //10
    setTimeout(() => { document.getElementById("counter").innerHTML = i;
    i = i - 1;}, timeout);
    timeout = timeout - 1000;
   }
   setTimeout(() => { document.getElementById("counter").innerHTML = "blastoff";
   i = i - 1}, timeout);
   timeout = timeout - 1000;
    //9
    setTimeout(() => { document.getElementById("counter").innerHTML = i;
    i = i - 1;}, timeout);
    timeout = timeout - 1000;

    //8
    setTimeout(() => { document.getElementById("counter").innerHTML = i;
    i = i - 1;}, timeout);
    timeout = timeout - 1000;
        
    //7
    setTimeout(() => { document.getElementById("counter").innerHTML = i;
    i = i - 1;}, timeout);
    timeout = timeout - 1000;

    //6
    setTimeout(() => { document.getElementById("counter").innerHTML = i;
    i = i - 1;}, timeout);
    timeout = timeout - 1000;
    
    //5
    setTimeout(() => { document.getElementById("counter").innerHTML = i;
    i = i - 1;}, timeout);
    timeout = timeout - 1000;

    //4
    setTimeout(() => { document.getElementById("counter").innerHTML = i;
    i = i - 1;}, timeout);
    timeout = timeout - 1000;

    //3
    setTimeout(() => { document.getElementById("counter").innerHTML = i;
    i = i - 1;}, timeout);
    timeout = timeout - 1000;

    //2
    setTimeout(() => { document.getElementById("counter").innerHTML = i;
    i = i - 1;}, timeout);
    timeout = timeout - 1000;

    //1
    setTimeout(() => { document.getElementById("counter").innerHTML = i;
    i = i - 1;}, timeout);
    timeout = timeout - 1000;


    setTimeout(() => { document.getElementById("counter").innerHTML = i;
    i = i - 1;}, timeout);
    timeout = timeout - 1000;
    
    //tried down here aswell    
 if (i == 5)
    {
        alert("halfway there")
    } 
    */
function gamble()
{
    //This line gets the information from the input and makes it a int
    var i = document.getElementById("gimme").value;
    //This line gives a random number to guess
    var x = Math.floor(Math.random() * 10);
    //this if else statement compares the two numbers decides whether you win or lose
    if (i==x)
    {
        alert("YAY you got it right. Your Number was " + i + " The Correct Number was " + x);
    }
    else
    {
        alert("Oh NO you were wrong. Your Number was " + i + " The Correct Number was " + x);
    }
        
}
function login()
{
    
    //this line gets the information from the first name 
    var first = document.getElementById("firstname").value;
    //this line gets the information from the last name 
    var last = document.getElementById("lastname").value;
    //this line gets the information from the badge number
    var badge = document.getElementById("security code").value;
    
    if (first.length > 10 && last.length > 10 )
    {
        document.getElementById("login status").innerHTML = "login Rejected Try Again"
    }
    else if (badge.length != 3 || badge != 123)
    {
        document.getElementById("login status").innerHTML = "Badge authentification failed"
    }
    else
    {
       
       location.replace("Landing Page.html")
    }
    

}   
